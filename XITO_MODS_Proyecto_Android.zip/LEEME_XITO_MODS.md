# Proyecto Android: XITO MODS V4 (Edición Neón)

Este proyecto contiene el código fuente completo de la aplicación **XITO MODS** con **Login por Clave**, **Dashboard Neón**, **Burbuja Flotante** y **Panel Flotante Arrastrable/Redimensionable**, replicando la estructura visual de `HEX ESP.apk` pero personalizado con estética Cyberpunk Neón (`#00F5D4` Cian Neón y `#BC13FE` Púrpura Neón) y tu marca **XITO MODS**.

## Claves de Acceso Incluidas por Defecto
En `KeyAuthManager.java` vienen activadas estas claves maestras (30 días de validez):
- `XITOMODS-VIP`
- `XITO-NEON-V4`
- `XITO-INF71`
- `PATOHEX-INF71`

También puedes conectar tu propio archivo JSON en GitHub Pages cambiando la constante `REMOTE_API_BASE` en `KeyAuthManager.java`.

## Cómo Compilar el APK Fácilmente (Desde Celular o PC)

### Opción 1: Desde tu Celular con GitHub Actions (Sin usar PC)
1. Sube el contenido de este ZIP a un repositorio de tu cuenta de GitHub.
2. El archivo `.github/workflows/build-apk.yml` ya viene configurado: al subir los archivos, ve a la pestaña **Actions** de tu repositorio y descarga el artefacto **`XITO-MODS-APK`** (`app-debug.apk`) listo para instalar.

### Opción 2: En Android Studio / CodeAssist / AIDE
1. Abre la carpeta del proyecto en **Android Studio** o **CodeAssist (Android)**.
2. Ejecuta **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
